README


##  indexer2.0.py
A py file which index the json files and tokenize the content into txt file.

##  makeTXTtoJson.py
A py file which convert all txt files to json file.

##  outputAnaly.py
A py file which creates a json file with words frequency and the corresponding urls

##  ID_file.py
A py file which converts the txt file with hashed url index to a json file

##  idURL.py
A py file which makes a json file which id-url format instead of id-file_path format

##  prepare_for_break_out.ipynb
A jupyter notebook file which makes a json file with words' tf-idf weight and the corresponding urls

##  break_out_whole_json.py
A py file which break out a large json file in order not to load the whole index file in the memory

##  demo.py
A py file which contains the logic of a simple search engine

##  GUI.py
A py file which shows a simple user interface design of a search engine

